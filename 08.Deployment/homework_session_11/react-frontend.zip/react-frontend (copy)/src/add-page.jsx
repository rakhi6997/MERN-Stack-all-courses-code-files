import React, { useState } from "react";

const Add = () => {
  let [num1, setNum1] = useState(0);
  let [num2, setNum2] = useState(0);
  let [response, setResponse] = useState("");

  const add = (e) => {
    e.preventDefault();

    fetch("http://localhost:5400/add", {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        num1: num1,
        num2: num2,
      }),
    })
      .then(
        (response) => response.json(), //ADDED >JSON() HERE

        (error) => console.log("An error occurred.", error)
      )
      .then((res) => setResponse("Addition is : " + res.message));
  };

  const onChangeNum1 = (event) => {
    setNum1(parseInt(event.target.value));
  };

  const onChangeNum2 = (event) => {
    setNum2(parseInt(event.target.value));
  };

  return (
    <div>
      <form onSubmit={add}>
        <h1>Hello Users</h1>
        <p>Enter First Number:</p>
        <input type="text" name="num1" value={num1} onChange={onChangeNum1} />
        <p>Enter Second Number:</p>
        <input type="text" name="num2" value={num2} onChange={onChangeNum2} />
        <br />
        <br />
        <input type="submit" />
      </form>
      <h3>{response}</h3>
    </div>
  );
};

export default Add;
